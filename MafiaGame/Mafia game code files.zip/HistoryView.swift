import SwiftUI

struct HistoryView: View {
    @Environment(GameHistoryStore.self) private var historyStore
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()
                
                if historyStore.games.isEmpty {
                    VStack(spacing: 16) {
                        Image(systemName: "clock.arrow.circlepath")
                            .font(.system(size: 60))
                            .foregroundColor(.gray.opacity(0.3))
                        Text("No games played yet")
                            .font(.headline)
                            .foregroundColor(.gray)
                    }
                } else {
                    List {
                        // Summary Section
                        Section {
                            HStack(spacing: 20) {
                                StatView(title: "Games", value: "\(historyStore.totalGamesPlayed)")
                                StatView(title: "Mafia Wins", value: "\(historyStore.mafiaWins)")
                                StatView(title: "Crew Wins", value: "\(historyStore.crewWins)")
                            }
                            .listRowBackground(Color.clear)
                            .listRowInsets(EdgeInsets())
                            .padding(.vertical)
                        }
                        
                        // Achievements Section
                        Section(header: Text("Achievements")) {
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 16) {
                                    ForEach(badges) { badge in
                                        BadgeView(badge: badge)
                                    }
                                }
                                .padding(.vertical, 8)
                            }
                            .listRowBackground(Color.clear)
                            .listRowInsets(EdgeInsets())
                        }
                        
                        // Game List
                        Section(header: Text("Recent Games")) {
                            ForEach(historyStore.games) { game in
                                GameHistoryRow(game: game)
                            }
                        }
                    }
                    .scrollContentBackground(.hidden)
                }
            }
            .navigationTitle("Game History")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(.black, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                    .foregroundColor(.orange)
                }
            }
        }
    }
    
    struct Badge: Identifiable {
        let id = UUID()
        let name: String
        let icon: String
        let color: Color
    }
    
    var badges: [Badge] {
        var b: [Badge] = []
        
        // Logic for badges
        if historyStore.mafiaWins > 0 {
            b.append(Badge(name: "First Blood", icon: "drop.fill", color: .red))
        }
        if historyStore.crewWins >= 3 {
             b.append(Badge(name: "Guardian", icon: "shield.fill", color: .blue))
        }
        if historyStore.totalGamesPlayed >= 1 {
            b.append(Badge(name: "Newbie", icon: "figure.walk", color: .green))
        }
        if historyStore.totalGamesPlayed >= 5 {
            b.append(Badge(name: "Veteran", icon: "star.fill", color: .yellow))
        }
        
        if b.isEmpty {
            b.append(Badge(name: "Play to Unlock", icon: "lock.fill", color: .gray))
        }
        
        return b
    }
}

struct BadgeView: View {
    let badge: HistoryView.Badge
    
    var body: some View {
        VStack(spacing: 8) {
            Circle()
                .fill(badge.color.opacity(0.2))
                .frame(width: 60, height: 60)
                .overlay(
                    Image(systemName: badge.icon)
                        .font(.title)
                        .foregroundColor(badge.color)
                )
                .overlay(
                    Circle()
                        .stroke(badge.color.opacity(0.5), lineWidth: 1)
                )
            
            Text(badge.name)
                .font(.caption)
                .fontWeight(.bold)
                .foregroundColor(.white)
        }
        .padding(8)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.white.opacity(0.05))
        )
    }
}

// ... rest of structs ...
struct StatView: View {
    let title: String
    let value: String
    
    var body: some View {
        VStack {
            Text(value)
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.white)
            Text(title)
                .font(.caption)
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity)
    }
}

struct GameHistoryRow: View {
    let game: GameRecord
    
    var iconName: String {
        if game.winner.contains("Mafia") { return "moon.fill" }
        if game.winner.contains("Crew") || game.winner.contains("Town") { return "person.2.fill" }
        return "theatermasks.fill" // Jester
    }
    
    var color: Color {
        if game.winner.contains("Mafia") { return .red }
        if game.winner.contains("Crew") || game.winner.contains("Town") { return .blue }
        return .purple
    }
    
    var body: some View {
        HStack {
            Image(systemName: iconName)
                .foregroundColor(color)
                .frame(width: 30)
            
            VStack(alignment: .leading) {
                Text(game.winner + " Won")
                    .font(.headline)
                    .foregroundColor(.white)
                Text("\(game.playerCount) Players • \(timeString)")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            Text(dateString)
                .font(.caption2)
                .foregroundColor(.gray)
        }
        .listRowBackground(Color.gray.opacity(0.1))
    }
    
    var timeString: String {
        let minutes = Int(game.duration) / 60
        return "\(minutes) min"
    }
    
    var dateString: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        return formatter.string(from: game.date)
    }
}

#Preview {
    let store = GameHistoryStore()
    // Add dummy data for preview if empty
    if store.games.isEmpty {
        store.addGame(winner: "Mafia", playerCount: 5, duration: 600)
    }
    
    return HistoryView()
        .environment(store)
}
