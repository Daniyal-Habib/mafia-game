import SwiftUI

struct HomeView: View {
    @Environment(PlayerStore.self) private var playerStore
    @State private var pulseAnimation = false
    @State private var showHowToPlay = false
    @State private var showSettings = false
    @State private var showHistory = false
    
    @State private var hasSavedGame = false
    @State private var resumedSession: GameSession? = nil
    @State private var navigateToResume = false
    
    // Theme Colors
    let primaryColor = Color(red: 0.8, green: 0.2, blue: 0.1) // Dark Red
    let secondaryColor = Color(red: 1.0, green: 0.5, blue: 0.0) // Orange
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Dark background
                // Background Image
                // Background Image
                if let bgImage = UIImage(named: "HomeBackground") {
                    GeometryReader { geo in
                        Image(uiImage: bgImage)
                            .resizable()
                            .scaledToFill()
                            .frame(width: geo.size.width, height: geo.size.height, alignment: .top)
                            .clipped()
                    }
                    .ignoresSafeArea()
                } else {
                    LinearGradient(
                        colors: [Color.black, Color(red: 0.15, green: 0.05, blue: 0.02)],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                    .ignoresSafeArea()
                    
                    // DEBUG: Remove this after fixing
                    VStack {
                        Text("DEBUG: Image Not Found")
                            .foregroundColor(.red)
                            .background(Color.black)
                        Text("Please rename asset to: 'HomeBackground'")
                            .font(.caption)
                            .foregroundColor(.white)
                            .background(Color.black)
                    }
                    .padding(.top, 50)
                }
                
                VStack(spacing: 30) {

                    Spacer().frame(height: 220) // Moved buttons down to uncover logo
                    
                    // Buttons
                    VStack(spacing: 16) {
                        if hasSavedGame {
                            Button {
                                resumeGame()
                            } label: {
                                Text("Resume Game".uppercased())
                            }
                            .buttonStyle(GameButtonStyle(color: .green))
                        }
                        
                        NavigationLink(destination: NewGameView()) {
                            Text("New Game".uppercased())
                        }
                        .buttonStyle(GameButtonStyle())
                        
                        NavigationLink(destination: PlayersView()) {
                            Text("Players".uppercased())
                        }
                        .buttonStyle(GameButtonStyle())
                        
                        Button {
                            showHistory = true
                        } label: {
                            Text("Game History".uppercased())
                        }
                        .buttonStyle(GameButtonStyle())
                        
                        Button {
                            showSettings = true
                        } label: {
                            Text("Settings".uppercased())
                        }
                        .buttonStyle(GameButtonStyle())
                    }
                    .padding(.horizontal, 40)
                    .frame(maxWidth: 400)
                    
                    Spacer()
                    
                    // Footer
                    Text("v2.0 Beta")
                        .font(.caption)
                        .foregroundColor(.gray.opacity(0.4))
                        .padding(.bottom, 20)
                }
            }
            .navigationBarHidden(true)
            .navigationDestination(isPresented: $navigateToResume) {
                if let session = resumedSession {
                    GameplayView(gameSession: session)
                }
            }
            .sheet(isPresented: $showHowToPlay) {
                // Placeholder for now
                VStack {
                    Text("How to Play")
                        .font(.largeTitle)
                        .padding()
                    Text("Rules coming soon...")
                }
                .presentationDetents([.medium])
            }
            .sheet(isPresented: $showSettings) {
                SettingsView()
            }
            .sheet(isPresented: $showHistory) {
                HistoryView()
            }
        }
    }
    
    private func resumeGame() {
        let session = GameSession()
        if GamePersistenceManager.shared.loadGame(into: session) {
            resumedSession = session
            navigateToResume = true
        }
    }
}


#Preview {
    HomeView()
        .environment(PlayerStore())
}
